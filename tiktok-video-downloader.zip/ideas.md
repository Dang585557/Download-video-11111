# TikTok Video Downloader — Design Ground Truth

## Reference specification
ภาพอ้างอิงของผู้ใช้เป็นหน้าดาวน์โหลดวิดีโอแบบ single-column ที่เน้น mobile-first: พื้นหลังดำเกือบสนิท, หัวเรื่องไล่สีฟ้า-ม่วง, ช่องวางลิงก์ในแผงกระจกสีน้ำเงินเข้ม, ปุ่ม Check สีฟ้าสด, พื้นที่โฆษณาแบบวิดีโอ, การ์ด About และข้อความเตือนการใช้งานส่วนบุคคล การนำเสนอควรคงลำดับและอารมณ์ของภาพนี้ แต่ยกระดับ spacing, contrast, typography และ motion ให้ดูเป็นผลิตภัณฑ์จริงบนมือถือและเดสก์ท็อป

## Chosen approach: Reference-matched dark signal interface

### Design Movement
Neo-digital editorial interface: glassmorphism ที่ลดความฟุ้ง, neon signal accents ที่ใช้เฉพาะจุด, และ typography แบบ technical display เพื่อให้ภาพรวมทันสมัยแต่ยังอ่านง่าย

### Core Principles
1. **Signal first** — หัวเรื่องและ CTA ต้องเด่นที่สุด เพื่อให้ผู้ใช้เข้าใจการกระทำหลักภายในไม่กี่วินาที
2. **Quiet depth** — ใช้พื้นผิวและแสงแบบ low-contrast แทน gradient ที่ฉูดฉาด เพื่อให้ข้อมูลไม่ถูกกลบ
3. **Mobile-first clarity** — รักษา single-column rhythm และ touch target ที่ใหญ่พอ โดยขยายเป็น split rhythm บนจอใหญ่อย่างมีเหตุผล
4. **Honest utility** — แสดงสถานะ ตรวจสอบลิงก์ และข้อความด้านลิขสิทธิ์อย่างชัดเจน ไม่สื่อว่ามี backend download จริงใน static demo

### Color Philosophy
ฐานสีเป็น ink black และ midnight navy เพื่อให้เนื้อหาหลักลอยขึ้นเหมือนหน้าจอในสภาพแสงน้อย Cyan ใช้แทนสถานะพร้อมใช้งานและความเร็ว ส่วน pink ใช้เป็น signal accent สำหรับความมีชีวิตชีวาและ brand recognition; purple ทำหน้าที่เป็นสะพานระหว่างสองสี ไม่ใช้เป็นพื้นหลังหลัก

### Layout Paradigm
Single-column content spine ที่เยื้องเล็กน้อยด้วย `max-width` และขอบซ้ายสี signal ใน desktop; บนมือถือเรียงเป็นลำดับ: identity → input → main ad → supporting ads → explanation → footer หลีกเลี่ยง hero ที่สูงเกินไปและรักษาจุดป้อนลิงก์ให้อยู่เหนือ fold

### Signature Elements
- เส้น signal gradient บาง ๆ ที่ขอบบนของ panel และ underline ของหัวข้อ
- ไอคอนวิดีโอทรงเส้นพร้อม pulse ring ในจุดที่เกี่ยวกับ video
- ป้ายสถานะเล็กแบบ `READY / INPUT REQUIRED` ที่ทำให้ interface รู้สึกมี feedback

### Interaction Philosophy
ทุกการกระทำต้องตอบสนองทันทีด้วย state ที่เห็นได้: ปุ่ม Check เปลี่ยนเป็น Checking, invalid URL แสดงคำแนะนำที่สุภาพ, URL ที่ถูกต้องแสดง ready state โดยไม่สัญญาว่าดาวน์โหลดได้จริงจนกว่าจะมี backend

### Animation
ใช้ entrance fade + translate เพียง 180–260ms, stagger 40ms ต่อ section; hover ใช้การเปลี่ยน opacity/box-shadow/transform เท่านั้น; button active scale 0.97; pulse ring รอบ video icon เคลื่อนช้าและหยุดเมื่อ `prefers-reduced-motion: reduce`

### Typography System
ใช้ `Space Grotesk` สำหรับ display, labels และ UI controls เพื่อความ technical; ใช้ `DM Sans` สำหรับ body copy เพื่ออ่านง่ายบนมือถือ ลำดับ: eyebrow 11px uppercase tracking, h1 clamp(2.15rem, 6vw, 4.75rem), section title 1.35rem, body 0.98rem/1.7

### Brand Essence
เครื่องมือวางลิงก์ TikTok ที่ทำให้การตรวจสอบไฟล์เริ่มต้นได้ในจังหวะเดียว สำหรับผู้ใช้ที่ต้องการ workflow ที่เร็วและชัดเจน โดยต่างจาก downloader ทั่วไปด้วยความโปร่งใสเรื่องสถานะและการใช้งาน

Personality: **เร็ว, ชัดเจน, น่าเชื่อถือ**

### Brand Voice
หัวข้อพูดสั้น ตรง และมีจังหวะ; CTA ใช้คำกริยาที่ระบุการกระทำ; microcopy อธิบายข้อจำกัดโดยไม่ขู่หรือกล่าวอ้างเกินจริง

ตัวอย่าง:
- “วางลิงก์ แล้วเช็กให้ชัด”
- “พร้อมตรวจสอบ — ส่งลิงก์ TikTok มาได้เลย”

### Wordmark & Logo
ใช้สัญลักษณ์ abstract ที่ผสานกรอบวิดีโอแนวตั้งกับ play triangle และคลื่น signal สองเส้น โดยวางเป็น mark ข้างชื่อ `ClipSignal` ใน header และใช้ mark เดียวกันเป็น favicon; ห้ามใช้ชื่อแบรนด์เป็นโลโก้ด้วยฟอนต์เริ่มต้น

### Signature Brand Color
`Signal Cyan #21D4FD` — สีที่เป็นเจ้าของได้ ทำหน้าที่เป็นเส้นนำสายตาและสถานะพร้อมใช้งาน โดยจับคู่กับ `Pulse Pink #FF4D9D` เฉพาะจุดเพื่อสร้างลายเซ็นของแบรนด์
