import json
from pathlib import Path

payload = json.loads(Path('/tmp/socialkit-preview.json').read_text())
data = payload.get('data') if isinstance(payload, dict) else None
print(json.dumps({
    'success': payload.get('success') if isinstance(payload, dict) else None,
    'hasData': isinstance(data, dict),
    'fields': sorted(data.keys()) if isinstance(data, dict) else [],
    'sample': {key: data.get(key) for key in ('title', 'description', 'channelName', 'views', 'likes', 'comments', 'shares', 'thumbnailUrl') if isinstance(data, dict) and key in data},
    'error': payload.get('error') or payload.get('message') if isinstance(payload, dict) else None,
}))
