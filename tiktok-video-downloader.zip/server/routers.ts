import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

const RATE_LIMIT_WINDOW_MS = 60_000;
const RATE_LIMIT_MAX = 5;
const attempts = new Map<string, number[]>();
const PLATFORM_HOSTS = {
  tiktok: /(^|\.)tiktok\.com$/i,
  youtube: /(^|\.)youtube\.com$|(^|\.)youtu\.be$/i,
  instagram: /(^|\.)instagram\.com$/i,
  facebook: /(^|\.)facebook\.com$|(^|\.)fb\.watch$/i,
} as const;
const downloadEndpoints = {
  tiktok: "https://api.socialkit.dev/tiktok/download",
  youtube: "https://api.socialkit.dev/youtube/download",
  instagram: "https://api.socialkit.dev/instagram/download",
} as const;
const statsEndpoints = {
  tiktok: "https://api.socialkit.dev/tiktok/stats",
  youtube: "https://api.socialkit.dev/youtube/stats",
  instagram: "https://api.socialkit.dev/instagram/stats",
  facebook: "https://api.socialkit.dev/facebook/stats",
} as const;

export function isAllowedDownloadRequest(clientKey: string, now = Date.now()) {
  const recent = (attempts.get(clientKey) ?? []).filter(timestamp => now - timestamp < RATE_LIMIT_WINDOW_MS);
  if (recent.length >= RATE_LIMIT_MAX) { attempts.set(clientKey, recent); return false; }
  recent.push(now); attempts.set(clientKey, recent); return true;
}

export type SupportedPlatform = keyof typeof PLATFORM_HOSTS;

export function detectPlatform(value: string): SupportedPlatform | null {
  try {
    const parsed = new URL(value);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") return null;
    const host = parsed.hostname.toLowerCase();
    return (Object.entries(PLATFORM_HOSTS).find(([, pattern]) => pattern.test(host))?.[0] as SupportedPlatform | undefined) ?? null;
  } catch { return null; }
}

export function isSafeSocialUrl(value: string) { return detectPlatform(value) !== null; }
export const isSafeTikTokUrl = (value: string) => detectPlatform(value) === "tiktok";

function valueOf(data: Record<string, unknown>, ...keys: string[]) {
  for (const key of keys) if (data[key] !== undefined && data[key] !== null && data[key] !== "") return data[key];
  return undefined;
}

function normalizeMetadata(platform: SupportedPlatform, originalUrl: string, payload: unknown) {
  if (!payload || typeof payload !== "object") return null;
  const root = payload as Record<string, unknown>;
  const data = root.data && typeof root.data === "object" ? root.data as Record<string, unknown> : root;
  if (data.isVideo === false || data.contentType === "carousel") throw new Error("The URL is not a video.");
  return {
    platform,
    url: originalUrl,
    title: String(valueOf(data, "title", "description") ?? ""),
    author: valueOf(data, "author", "channelName", "channelHandle", "username"),
    profilePicture: valueOf(data, "profilePicture", "avatar", "avatarUrl", "authorAvatar"),
    thumbnail: valueOf(data, "thumbnail", "thumbnailUrl"),
    views: valueOf(data, "views", "viewCount"),
    likes: valueOf(data, "likes", "likeCount"),
    comments: valueOf(data, "comments", "commentCount"),
    shares: valueOf(data, "shares", "shareCount"),
    saves: valueOf(data, "collects", "saves", "saveCount"),
    publishedAt: valueOf(data, "publishedAt", "timestamp"),
    duration: valueOf(data, "duration"),
    durationSeconds: valueOf(data, "durationSeconds"),
    fileSize: valueOf(data, "fileSizeMB", "fileSize"),
    qualities: Array.isArray(data.qualities) ? data.qualities.filter((item): item is string => typeof item === "string") : (typeof data.quality === "string" ? [data.quality] : []),
    canDownload: platform !== "facebook",
  };
}

async function socialFetch(url: string, init?: RequestInit) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25_000);
  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    const text = await response.text();
    let payload: unknown; try { payload = JSON.parse(text); } catch { payload = null; }
    if (!response.ok) throw new Error(`SocialKit returned ${response.status}.`);
    return payload;
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") throw new Error("The service timed out. Please try again.");
    throw error instanceof Error ? error : new Error("The service is unavailable.");
  } finally { clearTimeout(timeout); }
}

const inputShape = z.object({ url: z.string().trim().url().max(2048) });
const downloadInput = inputShape.extend({ format: z.enum(["mp4", "mp3", "avi", "webm", "m4a", "ogg", "wav"]).default("mp4"), quality: z.enum(["240p", "360p", "480p", "720p", "1080p"]).optional() });

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { const options = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(COOKIE_NAME, { ...options, maxAge: -1 }); return { success: true } as const; }),
  }),
  downloader: router({
    preview: publicProcedure.input(inputShape).mutation(async ({ input, ctx }) => {
      const platform = detectPlatform(input.url);
      if (!platform) throw new Error("Unsupported URL. Use a public TikTok, YouTube, Facebook, or Instagram video URL.");
      const accessKey = process.env.SOCIALKIT_ACCESS_KEY;
      if (!accessKey) throw new Error("Preview service is not configured.");
      const params = new URLSearchParams({ access_key: accessKey, url: input.url });
      const payload = await socialFetch(`${statsEndpoints[platform]}?${params}`);
      const metadata = normalizeMetadata(platform, input.url, payload);
      if (!metadata) throw new Error("Unable to retrieve video information.");
      return metadata;
    }),
    download: publicProcedure.input(downloadInput).mutation(async ({ input, ctx }) => {
      const platform = detectPlatform(input.url);
      if (!platform) throw new Error("Unsupported URL.");
      if (platform === "facebook") throw new Error("Facebook preview is available, but download is not supported by the current API.");
      if (!input.quality) throw new Error("This video has no quality option returned by the API, so download is unavailable.");
      if (!isAllowedDownloadRequest(ctx.req.ip || ctx.req.socket?.remoteAddress || "unknown")) throw new Error("Too many download requests. Please wait a minute and try again.");
      const accessKey = process.env.SOCIALKIT_ACCESS_KEY;
      if (!accessKey) throw new Error("Download service is not configured.");
      const payload = await socialFetch(downloadEndpoints[platform], { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ access_key: accessKey, url: input.url, format: input.format, quality: input.quality }) });
      const metadata = normalizeMetadata(platform, input.url, payload) as Record<string, unknown> | null;
      const data = payload && typeof payload === "object" && (payload as any).data && typeof (payload as any).data === "object" ? (payload as any).data : payload as any;
      const downloadUrl = valueOf(data ?? {}, "downloadUrl", "download_url");
      if (!metadata || typeof downloadUrl !== "string") throw new Error("Unable to retrieve a usable download URL.");
      return { ...metadata, downloadUrl, format: valueOf(data, "format") ?? input.format, quality: valueOf(data, "quality") ?? input.quality, expiresIn: valueOf(data, "expiresIn") };
    }),
  }),
});

export type AppRouter = typeof appRouter;
